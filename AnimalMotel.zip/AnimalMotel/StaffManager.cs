﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalMotel
{
    public class StaffManager : ListManager<Staff>
    {
        // No code needed atm. Only makes use of inherited members.
    }
}
