﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalMotel
{
    public class RecipeManager : ListManager<Recipe>
    {
        // No code needed atm. Only makes use of inherited members.
    }
}
